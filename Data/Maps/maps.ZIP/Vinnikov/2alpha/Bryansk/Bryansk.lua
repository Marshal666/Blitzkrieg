function CallHelp1()
	if (GetNUnitsInCircle (0, 4613, 8577, 880) > 2) then
		GiveCommand( 5, 10, 5300, 7900 );
		KillScript("CallHelp2");
		Suicide();
	end;
end;

function CallHelp2()
	if (GetNUnitsInCircle (0, 5700, 2240, 850) > 2) then
		GiveCommand( 5, 10, 7200, 1900 );
		KillScript("CallHelp1");
		Suicide();
	end;
end;

function ToWin()
	if (GetNUnitsInScriptGroup (1) <= 0) then
		Win();
		Suicide();
	end;
end;

function Init()
	RunScript( "CallHelp1", 2000);
	RunScript( "CallHelp2", 2000);
	RunScript( "ToWin", 10000);
end;
