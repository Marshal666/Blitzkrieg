function EnterBuildE()
	GiveCommand( 8, 20, 21);
	GiveCommand( 8, 22, 23);
	GiveCommand( 8, 24, 25);
	GiveCommand( 8, 26, 27);

	GiveCommand( 8, 100, 101);
	GiveCommand( 8, 102, 101);
	GiveCommand( 8, 104, 103);
	GiveCommand( 8, 106, 107);
	GiveCommand( 8, 108, 109);
	GiveCommand( 8, 110, 111);
	GiveCommand( 8, 112, 111);
	GiveCommand( 8, 114, 113);
	GiveCommand( 8, 116, 113);
	GiveCommand( 8, 118, 119);
	GiveCommand( 8, 120, 119);
	GiveCommand( 8, 122, 123);
	GiveCommand( 8, 124, 123);
	GiveCommand( 8, 126, 127);
	GiveCommand( 8, 128, 129);
	GiveCommand( 8, 130, 131);
	GiveCommand( 8, 132, 133);
	GiveCommand( 8, 134, 135);
	GiveCommand( 8, 136, 135);

	Suicide();
end;

function CallHelp1()
	if (GetNUnitsInScriptGroup (2) <= 5) then
		GiveCommand( 5, 10, 5800, 8700 );
		KillScript("CallHelp2");
		Suicide();
	end;
end;

function CallHelp2()
	if (GetNUnitsInScriptGroup (1) <= 5) then
		GiveCommand( 5, 10, 6900, 2400 );
		KillScript("CallHelp1");
		Suicide();
	end;
end;

function ToWin()
	if (GetNUnitsInArea (0, "Station") > 2) then
		Win();
		Suicide();
	end;
end;

function TobeDefeated()
	if (GetNUnitsInScriptGroup (1000) <= 0) then
	Loose();
	Suicide();
	end;
end;

function Init()
	RunScript( "EnterBuildE", 2000);
	RunScript( "CallHelp1", 2000);
	RunScript( "CallHelp2", 2000);
	RunScript( "ToWin", 10000);
	RunScript( "TobeDefeated", 6000);
end;
