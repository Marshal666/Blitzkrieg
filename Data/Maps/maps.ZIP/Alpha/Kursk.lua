function ToDzot()
	GiveCommand(8, 150,151);
	GiveCommand(8, 152,153);
	GiveCommand(8, 154,155);
	GiveCommand(8, 156,157);

	GiveCommand(8, 200,201);
	GiveCommand(8, 202,203);
	GiveCommand(8, 204,205);
	GiveCommand(8, 206,207);
	GiveCommand(8, 208,209);
	GiveCommand(8, 210,211);
	GiveCommand(8, 212,213);
	GiveCommand(8, 214,215);
	GiveCommand(8, 216,217);
	GiveCommand(8, 218,219);
	GiveCommand(8, 220,221);
	GiveCommand(8, 222,223);
	GiveCommand(8, 224,225);
	GiveCommand(8, 226,227);
	GiveCommand(8, 228,229);
	GiveCommand(8, 230,231);
	GiveCommand(8, 232,233);
	GiveCommand(8, 234,235);
	GiveCommand(8, 236,237);
	GiveCommand(8, 238,239);
	GiveCommand(8, 240,241);
	GiveCommand(8, 242,243);
	GiveCommand(8, 244,245);
	GiveCommand(8, 246,247);
	GiveCommand(8, 248,249);
	GiveCommand(8, 250,251);
	GiveCommand(8, 252,253);
	GiveCommand(8, 254,255);
	GiveCommand(8, 256,257);
	GiveCommand(8, 258,259);
	GiveCommand(8, 260,261);
	GiveCommand(8, 262,263);
	GiveCommand(8, 264,265);
	GiveCommand(8, 266,267);
	GiveCommand(8, 268,269);
	GiveCommand(8, 270,271);
end;

function Reinforce1E()
	LandReinforcement( 1);
	Suicide();
end;


function Reinforce11E()
	LandReinforcement( 11);
	Suicide();
end;

function Reinforce12E()
	LandReinforcement( 12);
	Suicide();
end;

function Reinforce13E()
	LandReinforcement( 13);
	Suicide();
end;

function Reinforce2E()
	LandReinforcement( 2);
	Suicide();
end;

function Reinforce21E()
	LandReinforcement( 21);
	Suicide();
end;

function Reinforce3E()
	LandReinforcement( 3);
	Suicide();
end;

function Reinforce31E()
	LandReinforcement( 31);
	Suicide();
end;

function Reinforce32E()
	LandReinforcement( 32);
	Suicide();
end;

function Reinforce33E()
	LandReinforcement( 33);
	Suicide();
end;

function Reinforce34E()
	LandReinforcement( 34);
	Suicide();
end;

function Reinforce4E()
	LandReinforcement( 4);
	Suicide();

end;

function Reinforce41E()
	LandReinforcement( 41);
	Suicide();

end;

function Reinforce42E()
	LandReinforcement( 42);
	Suicide();

end;

function Reinforce5E()
	LandReinforcement( 5);
	Suicide();
end;

function Reinforce51E()
	LandReinforcement( 51);
	Suicide();
end;

function Reinforce52E()
	LandReinforcement( 52);
	Suicide();
end;

function ReinforceUSSR1()
	LandReinforcement( 100);
	Suicide();
end;

function ReinforceUSSR2()
	LandReinforcement( 101);
	Suicide();
end;

function Attack1inf()
	if (GetNUnitsInScriptGroup(10) > 0) then
	GiveCommand( 5, 10, 2500, 9700);
	Suicide();
	end;
end;

function Attack1()
	if (GetNUnitsInScriptGroup(1) > 0) then
	GiveCommand( 5, 1, 2500, 9700);
	Suicide();
	end;
end;

function Attack11()
	if (GetNUnitsInScriptGroup(11) > 0) then
	GiveCommand( 5, 11, 2500, 9700);
	Suicide();
	end;
end;

function Attack12()
	if (GetNUnitsInScriptGroup(12) > 0) then
	GiveCommand( 5, 12, 2500, 9700);
	Suicide();
	end;
end;

function Attack2()
	if (GetNUnitsInScriptGroup(2) > 0) then
	GiveCommand( 5, 2, 3800, 5400);
	GiveQCommand( 5, 2, 3700, 9500);
	Suicide();
	end;
end;

function Attack21()
	if (GetNUnitsInScriptGroup(21) > 0) then
	GiveCommand( 5, 21, 3800, 5400);
	GiveQCommand( 5, 21, 3700, 9500);
	Suicide();
	end;
end;

function Attack3()
	if (GetNUnitsInScriptGroup(3) > 0) then
	GiveCommand( 5, 3, 6000, 9000);
	Suicide();
	end;
end;

function Attack31()
	if (GetNUnitsInScriptGroup(31) > 0) then
	GiveCommand( 5, 31, 6000, 9000);
	Suicide();
	end;
end;

function Attack32()
	if (GetNUnitsInScriptGroup(32) > 0) then
	GiveCommand( 5, 32, 6000, 9000);
	Suicide();
	end;
end;

function Attack33()
	if (GetNUnitsInScriptGroup(33) > 0) then
	GiveCommand( 5, 33, 6000, 9000);
	Suicide();
	end;
end;

function Attack34()
	if (GetNUnitsInScriptGroup(34) > 0) then
	GiveCommand( 5, 34, 6000, 9000);
	Suicide();
	end;
end;

function Attack4()
	if (GetNUnitsInScriptGroup(4) > 0) then
	GiveCommand( 5, 4, 5900, 9500);
	Suicide();
	end;
end;

function Attack41()
	if (GetNUnitsInScriptGroup(41) > 0) then
	GiveCommand( 5, 41, 5900, 9500);
	Suicide();
	end;
end;

function Attack42()
	if (GetNUnitsInScriptGroup(42) > 0) then
	GiveCommand( 5, 42, 5900, 9500);
	Suicide();
	end;
end;

function Attack5inf()
	if (GetNUnitsInScriptGroup(50) > 0) then
	GiveCommand( 5, 50, 4100, 9500);
	Suicide();
	end;
end;

function Attack5()
	if (GetNUnitsInScriptGroup(5) > 0) then
	GiveCommand( 5, 5, 4100, 9500);
	Suicide();
	end;
end;

function Attack51()
	if (GetNUnitsInScriptGroup(51) > 0) then
	GiveCommand( 5, 51, 4100, 9500);
	Suicide();
	end;
end;

function Attack52()
	if (GetNUnitsInScriptGroup(52) > 0) then
	GiveCommand( 5, 52, 4100, 9500);
	Suicide();
	end;
end;

function ToWin()
	if (GetNUnitsInScriptGroup(99) <= 0) then
		Win();
		Suicide();
	end;
end;

function TobeDefeated()
	if (GetNUnitsInScriptGroup(1000) <= 0) then
	Loose();
	Suicide();
	end;
end;

function Init()
	RunScript( "ToDzot", 4000);

	RunScript( "Reinforce1E", 40000);
	RunScript( "Reinforce2E", 41000);
	RunScript( "Reinforce3E", 46000);
	RunScript( "Reinforce5E", 47000);
	RunScript( "Attack1inf", 42000);
	RunScript( "Attack1", 54000);
	RunScript( "Attack2", 43000);
	RunScript( "Attack3", 47000);
	RunScript( "Attack5inf", 48000);
	RunScript( "Attack5", 60000);

	RunScript( "Reinforce11E", 320000);
	RunScript( "Reinforce31E", 286000);
	RunScript( "Reinforce4E", 230000);
	RunScript( "Reinforce51E", 355000);
	RunScript( "Attack11", 325000);
	RunScript( "Attack31", 287000);
	RunScript( "Attack4", 240000);
	RunScript( "Attack51", 360000);
	
	RunScript( "Reinforce12E", 480000);
	RunScript( "ReinforceUSSR1", 500000);
	RunScript( "Reinforce32E", 540000);
	RunScript( "Reinforce41E", 600000);
	RunScript( "Attack12", 485000);
	RunScript( "Attack32", 545000);
	RunScript( "Attack41", 605000);

	RunScript( "Reinforce21E", 780000);
	RunScript( "Reinforce33E", 900000);
	RunScript( "Reinforce52E", 960000);
	RunScript( "Attack21", 785000);
	RunScript( "Attack33", 905000);
	RunScript( "Attack52", 965000);

	RunScript( "ReinforceUSSR2", 1000000);
	RunScript( "Reinforce13E", 1020000);
	RunScript( "Reinforce34E", 1040000);
	RunScript( "Reinforce42E", 1000000);
	RunScript( "Attack13", 1025000);
	RunScript( "Attack34", 1045000);
	RunScript( "Attack42", 1005000);

	RunScript( "ToWin", 10000);
end;
