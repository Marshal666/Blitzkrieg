function EnterBuildE()
	GiveCommand( 8, 8, 11);
	GiveCommand( 8, 9, 12);

	GiveCommand( 8, 100, 101);
	GiveCommand( 8, 102, 103);
	GiveCommand( 8, 104, 105);
	GiveCommand( 8, 106, 107);
	GiveCommand( 8, 108, 109);
	GiveCommand( 8, 110, 111);
	GiveCommand( 8, 112, 113);
	GiveCommand( 8, 114, 115);
	GiveCommand( 8, 116, 117);
	GiveCommand( 8, 118, 119);
	GiveCommand( 8, 120, 121);
	GiveCommand( 8, 122, 123);
	GiveCommand( 8, 124, 125);
	GiveCommand( 8, 126, 127);
	Suicide();
end;

function Reinforce1E()
	LandReinforcement( 3);
	Suicide();
end;

function Reinforce2E()
	LandReinforcement( 1);
	Suicide();
end;

function Reinforce3E()
	LandReinforcement( 4);
end;

function ReinforceUSSR()
	LandReinforcement( 2);
	GiveCommand(1, 10, 8500, 2200);
	Suicide();
end;

function ToWin()
	if (GetNUnitsInScriptGroup(95) <= 0 ) then
	if (GetNUnitsInScriptGroup(5) <= 0 ) then
	Win();
	Suicide();
	end;
	end;
end;

function TobeDefeated()
	if (GetNUnitsInScriptGroup(1000) <= 0 ) then
	if (GetNUnitsInScriptGroup(10) <= 0 ) then
	Loose();
	Suicide();
	end;
	end;
end;

function Attack1()
	if ( GetNUnitsInScriptGroup( 1 ) > 0) then
		GiveCommand( 5, 1, 5100, 3000);
		GiveQCommand( 5, 1, 7100, 3000);
	end;
	if ( GetNUnitsInScriptGroup( 51 ) > 0) then
		GiveCommand( 5, 51, 5100, 1600);
		GiveQCommand( 5, 51, 8200, 1600);
	end;
	Suicide();
end;

function Attack2()
	if ( GetNUnitsInScriptGroup( 2 ) > 0) then
		GiveCommand( 5, 2, 5100, 3000);
		GiveQCommand( 5, 2, 7100, 3000);
	end;
	if ( GetNUnitsInScriptGroup( 52 ) > 0) then
		GiveCommand( 5, 52, 5100, 1600);
		GiveQCommand( 5, 52, 8200, 1600);
	end;
	Suicide();
end;

function Attack3()
	if ( GetNUnitsInScriptGroup( 4 ) > 0) then
		GiveCommand( 5, 4, 5100, 3000);
		GiveQCommand( 5, 4, 7100, 3000);
	end;
	if ( GetNUnitsInScriptGroup( 24 ) > 0) then
		GiveCommand( 5, 54, 5100, 1600);
		GiveQCommand( 5, 54, 8200, 1600);
	end;
end;

function AttackArti()
	if ( GetNUnitsInScriptGroup( 5 ) > 0) then
		GiveCommand( 36, 5, 6500, 2700);
		Suicide();
	end;
end;

function AttackArti2()
	if ( GetNUnitsInScriptGroup( 5 ) > 0) then
		GiveCommand( 35, 5);
		GiveQCommand( 10, 5, 7300, 2700);
		GiveQCommand( 34, 5);
		GiveQCommand( 36, 5, 7300, 2700);
		Suicide();
	end;
end;

function AttackArtiStop()
	if ( GetNUnitsInScriptGroup( 5 ) > 0) then
		GiveCommand( 11, 5);
		Suicide();
	end;
end;

function Init()
	RunScript( "EnterBuildE", 4000);
	RunScript( "Reinforce1E", 5000);
	RunScript( "Reinforce2E", 20000);
	RunScript( "Reinforce3E", 180000);
	RunScript( "AttackArti", 40000);
	RunScript( "AttackArti2", 50000);
	RunScript( "AttackArtiStop", 60000);
	RunScript( "ReinforceUSSR", 160000);
	RunScript( "Attack1", 6000);
	RunScript( "Attack2", 60000);
	RunScript( "Attack3", 181000);
	RunScript( "ToWin", 7000);
	RunScript( "TobeDefeated", 6000);
end;
