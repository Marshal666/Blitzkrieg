function EnterBldg()
	GiveCommand (8, 14, 15);
	GiveCommand (8, 16, 17);
	GiveCommand (8, 18, 19);
	GiveCommand (8, 20, 21);
	GiveCommand (8, 22, 23);
	GiveCommand (8, 24, 25);
	GiveCommand (8, 26, 27);
	GiveCommand (8, 28, 29);
	GiveCommand (8, 30, 31);
	Suicide();
end;

function BMmovefire()
	if (GetNUnitsInScriptGroup (5) > 0) then
		GiveCommand(35, 5);
		GiveQCommand(1, 5, 6900, 11050);
		GiveQCommand(10, 5, 3000, 11100);
		GiveQCommand(34, 5);
		GiveQCommand(36, 5, 3000, 11100);
		Suicide();
	end;
end;

function BMmoveout()
	if (GetNUnitsInScriptGroup (5) > 0) then
		GiveCommand(35, 5);
		GiveQCommand( 1, 5, 11000, 11000);
		Suicide();
	end;
end;

function Rush_KV1()
	if (GetNUnitsInScriptGroup (1) > 0) then
		GiveCommand( 5, 1, 3600, 10300);
		Suicide();
	end;
end;

function Rush_inf()
	if (GetNUnitsInScriptGroup (11) > 0) then
		GiveCommand( 5, 11, 500, 10600);
		GiveQCommand( 5, 11, 2900, 10000);
		Suicide();
	end;
end;

function Rush_T34_1()
	if (GetNUnitsInScriptGroup (2) > 0) then
		GiveCommand( 5, 2, 4000, 9700);
		Suicide();
	end;
end;

function Rush_T34_2()
	if (GetNUnitsInScriptGroup (3) > 0) then
		GiveCommand( 5, 3, 2300, 9900);
		Suicide();
	end;
end;

function Rush_T34_3()
	if (GetNUnitsInScriptGroup (4) > 0) then
		GiveCommand( 5, 4, 2300, 9900);
		Suicide();
	end;
end;

function Recapture()
	if (GetNUnitsInArea(0, "Capturable") >= 4) then
		ChangeParty (100, 0);
	if (GetNUnitsInScriptGroup (6) > 0) then
		GiveCommand( 5, 6, 9200, 2100);
		GiveQCommand( 5, 6, 10400, 2900);
	end;
	if (GetNUnitsInScriptGroup (7) > 0) then
		GiveCommand( 5, 7, 11200, 2200);
		GiveQCommand( 5, 7, 10400, 2900);
	end;
	Suicide();
	end;
end;

function BombersToStart()
	if (GetNUnitsInScriptGroup(1) > 0) then
	GiveCommand( 14, -1, 2900, 9900, 4);
	end;
end;

function BombersToStation()
	if (GetNUnitsInArea(0, "Capturable") > 2) then
	GiveCommand( 14, -1, 10300, 3800, 4);
	end;
end;

function ToWin()
	if (GetNUnitsInScriptGroup(14) <= 0) then
	Win();
	Suicide();
	end;
end;

function TobeDefeated()
	if (GetNUnitsInScriptGroup(1000) <= 0) then
	Loose();
	Suicide();
	end;
end;

function Init()
	RunScript( "EnterBldg", 3000);
	RunScript( "BMmovefire", 3000);
	RunScript( "BMmoveout", 93000);
	RunScript( "Rush_KV1", 100000);
	RunScript( "Rush_inf", 103000);
	RunScript( "Rush_T34_1", 108000);
	RunScript( "Rush_T34_2", 113000);
	RunScript( "Rush_T34_3", 133000);
	RunScript( "Recapture", 10000);
	RunScript( "BombersToStart", 50000);
	RunScript( "BombersToStation", 60000);
	RunScript( "ToWin", 10000);
	RunScript( "TobeDefeated", 6000);
end;
