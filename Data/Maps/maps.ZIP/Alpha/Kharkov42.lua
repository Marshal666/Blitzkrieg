function StartAttack()
	GiveCommand( 5, 1, 1400, 9500);
	Suicide();
end;

function Zhopa()
	GiveCommand(8, 300,301);
	GiveCommand(8, 302,301);
	GiveCommand(8, 304,305);
	GiveCommand(8, 306,307);
	GiveCommand(8, 308,307);
	GiveCommand(8, 310,311);
	GiveCommand(8, 312,311);
	GiveCommand(8, 314,315);
	GiveCommand(8, 316,315);
	GiveCommand(8, 318,319);
	GiveCommand(8, 320,321);
	GiveCommand(8, 322,321);
	GiveCommand(8, 324,325);
end;

function NearBridge()
	if (GetNUnitsInArea (0, "NearBridge") > 2) then
		GiveCommand( 5, 2, 1400, 9500);
		Suicide();
	end;
end;

function AntiArti1()
	if (GetNUnitsInScriptGroup (3) > 0) then
		GiveCommand( 35, 3);
		GiveQCommand( 10, 3, 3100, 12000);
		GiveQCommand( 34, 3);
		GiveQCommand( 36, 3, 3100, 12000);
		Suicide();
	end;
end;

function AntiArti1Stop()
	if (GetNUnitsInScriptGroup (3) > 0) then
		GiveCommand( 11, 3);
		Suicide();
	end;
end;

function CallHQ()
	GiveCommand(5, 9, 2700, 6900);
	GiveQCommand(5, 9, 7500, 8100);
	GiveQCommand(5, 9, 11100, 7300);
	GiveCommand(5, 8, 3300, 4400);
	GiveQCommand(5, 8, 6300, 4700);
	GiveQCommand(5, 8, 11300, 5400);
	Suicide();
end;

function ToWin()
	if (GetNUnitsInScriptGroup (9) <= 0) then
	if (GetNUnitsInScriptGroup (8) <= 0) then
	Win();
	Suicide();
	end;
	end;
end;

function Init()
	RunScript( "Zhopa", 5000);
	RunScript( "StartAttack", 10000);
	RunScript( "NearBridge", 3000);
	RunScript( "AntiArti1", 180000);
	RunScript( "AntiArti1Stop", 240000);
	RunScript( "ToWin", 7000);
end;
