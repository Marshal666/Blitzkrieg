function EnterBuildE()
	GiveCommand( 8, 5, 6);
	GiveCommand( 8, 7, 8);

	GiveCommand( 8, 100, 101);
	GiveCommand( 8, 102, 101);
	GiveCommand( 8, 104, 105);
	GiveCommand( 8, 106, 107);
	GiveCommand( 8, 108, 109);
	GiveCommand( 8, 110, 109);
	GiveCommand( 8, 112, 111);
	Suicide();
end;

function BridgeAttack()
	if (GetNUnitsInArea (0, "B1") > 0) then
		GiveCommand( 35, 2);
		GiveQCommand( 10, 2, 6700, 7900);
		GiveQCommand( 34, 2);
		GiveQCommand( 36, 2, 6700, 7900);
		Suicide();
	end;
end;

function ToWin()
	if (GetNUnitsInScriptGroup (10) <= 0) then
	if (GetNUnitsInArea(0, "Objective") > 0) then
		Win();
		Suicide();
	end;
	end;
end;
function TobeDefeated()
	if (GetNUnitsInScriptGroup (1000) <= 0) then
	Loose();
	Suicide();
	end;
end;

function Init()
	RunScript( "EnterBuildE", 3000);
	RunScript( "BridgeAttack", 5000);
	RunScript( "ToWin", 10000);
	RunScript( "TobeDefeated", 4000);
end;
